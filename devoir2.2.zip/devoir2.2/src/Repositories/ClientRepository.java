package Repositories;

import java.util.ArrayList;
import java.util.List;

import Entities.Client;

public class ClientRepository extends Database{
    private final  String SQL_SELECT_ALL="select * from Client" ;
    private final  String SQL_INSERT="INSERT INTO 'Client' ('id', 'nomComplet', 'telephone','email') VALUES (?,?,?,?)";
    public void insertClient(Client client) {
        // openConnexion();
        // try{
            
        
    
        // closeConnexion();
    }
    public  List<Client> getAllClients() {
        List<Client> clients=new ArrayList<>();
        f
    }
}
