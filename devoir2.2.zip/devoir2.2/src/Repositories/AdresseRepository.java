package Repositories;

import java.util.ArrayList;
import java.util.List;

import Entities.Adresse;
import Entities.Client;

public class AdresseRepository {
    private final  String SQL_SELECT_ALL="select * from Client cl, Adresse ad where cl.Client_id=ad.id_Adresse\"" ;
    private final  String SQL_INSERT="INSERT INTO Adresse (numVilla) VALUES (?)";
    public void insertAdresse(Adresse adresse){
        // openConnexion();
       
        // closeConnexion();
    }

    public List<Adresse>  getAllAdresse() {
        List<Adresse> adresses=new ArrayList<>();
        j
        
    }

}
