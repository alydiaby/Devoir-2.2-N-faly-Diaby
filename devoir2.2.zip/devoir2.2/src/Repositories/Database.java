package Repositories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Database {
    protected Connection connect=null;
     protected  PreparedStatement statement=null;
      public void  openConnexion(){
             try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connect= DriverManager.getConnection(
                    "jdbc:mysql://localhost:8889/devoir2.2",
             "aly", "aly123"); 
            } catch (ClassNotFoundException e) {
                System.out.println("Erreur");
            }
            catch (SQLException e) {
                System.out.println("Erreur ");
            } 
       }

       public void  closeConnexion(){
        if (connect!=null) {
           try {
               connect.close() ;
           } catch (SQLException e) {
               System.out.println("Erreur");
           }   
        }
   }
}
