package Services;

import java.util.List;

import Entities.Adresse;
import Repositories.AdresseRepository;

public class AdresseService {
    private AdresseRepository adresseRepository=new AdresseRepository();
    public void ajouterAdresse(Adresse adresse){
        adresseRepository.insertAdresse(adresse);
    }
    public List<Adresse> listerAdresse(){
          return adresseRepository.getAllAdresse();
    }
}
