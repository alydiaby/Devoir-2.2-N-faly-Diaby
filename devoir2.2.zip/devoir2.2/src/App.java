import java.util.List;
import java.util.Scanner;

import Entities.Adresse;
import Entities.Client;
import Services.AdresseService;
import Services.ClientService;

public class App {
    public static void main(String[] args) throws Exception {
        int choix;
        Scanner sc=new Scanner(System.in);
        ClientService clientService=new ClientService();
        AdresseService adresseService=new AdresseService();

        do {
            System.out.println("1-Creer un Client");
            System.out.println("2-Lister les Clients"); 
            System.out.println("3-Ajouter une adresse "); 
            System.out.println("4-Lister les  adresses ");
            System.out.println("5-Quitter"); 
             choix=sc.nextInt();
             sc.nextLine();
             

            switch (choix) {
                case 1:
                
                System.out.println("Entrer id du client: ");
                int id=sc.nextInt(); 
                System.out.println("Entrer le nomComplet du client: ");
                String nomComplet=sc.nextLine();
                System.out.println("Entrer le telephone du client: ");
                int telephone=sc.nextInt();
                System.out.println("Entrer l'email' du client: ");
                String email=sc.nextLine();
                Client client=new Client();
                client.setId(id);
                client.setNomComplet(nomComplet);
                client.setTelephone(telephone);
                client.setEmail(email);
                
                
                clientService.ajouterClient(client);
                break;
                case 2:
                    List<Client> clients= clientService.listerClient();
                   for (Client cl : clients) {
                       System.out.println("Id : "+cl.getId() ); 
                       System.out.println("Nom Complet : "+cl.getNomComplet() ); 
                       System.out.println("Telephone : "+cl.getTelephone() ); 
                       System.out.println("Email : "+cl.getEmail());     
                   }
                    break;

                case 3:
                System.out.println("Entrer id de l'adresse: ");
                int id_Adresse=sc.nextInt(); 
                System.out.println("Entrer la ville: ");
                String ville=sc.nextLine();
                System.out.println("Entrer le quartier: ");
                String quartier=sc.nextLine();
                System.out.println("Entrer numVilla: ");
                String numVilla=sc.nextLine();
                Adresse adresse= new Adresse();
                adresse.setId(id_Adresse);
                adresse.setVille(ville);
                adresse.setQuartier(quartier);
                adresse.setNumVilla(numVilla);

                adresseService.ajouterAdresse(adresse);

                    break;
            
                case 4:
                
                break;
                    
            }sc.close();
            
        } while (choix !=5);
        
    } 
}       
